const configuration = require("./configuration/commands.json");
const messages = require("./core/MessageManager.js");

const rc = [];

const prefix = configuration.prefix;

function execute(message, command, args){
  for(let c of rc){
    if(!c.hasExecutor(command)) continue;
    c.execute(message, args);
    return true;
  }
  return false;
}

module.exports = registerCommand;
function registerCommand(command){
  rc.push(command);
}

module.exports = registerListener;
function registerListener(client){
  const notfound = messages.getMessage("COMMAND_NOT_FOUND");
  client.on("message", function(message) {
    if(message.author.bot) return;
    if(message.content.startsWith(prefix)){
      const ex = message.content.split(" ",2);
      const command = ex[0].replace(prefix, "");
      const args = ex.length == 1? [] : ex[1].split(" ");
      
      if(execute(message, command, args)) return;
      notfount.sendMessage(message);
      return;
    }
  });
}