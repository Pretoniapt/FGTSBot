const configuration = require("./configuration/messages.json");
const {Format} = require("./model/MessageFormat.js");
const messages = new Map();

module.exports = loadAll;
module.exports = getMessage;

function getMessage(message){
  return messages.get(message);
}

function loadAll(){
  for(let m of configuration){
    const builder = new Format();
    if(m.hasOwnProperty("COLOR")) builder.setColor(m.COLOR);
    if(m.hasOwnProperty("TITLE")) builder.setTitle(m.TITLE);
    messages.set(m, builder);
  }
}