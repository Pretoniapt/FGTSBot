class FieldFormat{
  constructor(title, text, inline){
    this.title = title; this.text = text; this.inline = inline;
  }
  
  setTitle(title){this.title = title;}
  getTitle(){return title;}
  
  setText(text){this.text = text;}
  getText(){return text;}
  
  setInline(inline){this.inline = inline;}
  getInline(){return this.inline;}
}