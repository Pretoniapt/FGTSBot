const cm = require("./commands/CommandManager.js");

class GenericCommand{
  
  constructor(permission, executors){
    this.permission = permission;
    this.executors = executors;
    cm.registerCommand(this);
  }
  
  hasExecutor(command){
    return this.executors.includes(command);
  }
  
  execute(message, args){}
}