const {MessageEmbed} = require("discord.js");
const {FieldFormat} = require("/model/FieldFormat.js");

class MessageFormat{
  
  constructor(){
    this.type = "NORMAL";
    this.text = "Error: Mensagem vazia! Reporte a equipe do servidor...";
    this.color = "BLACK";
    this.title = null;
    this.description = null;
    this.author = null;
    this.authorIcon = null;
    this.authorUrl = null;
    this.thumbnail = null;
    this.image = null;
    this.timestamp = false;
    this.footerText = null;
    this.footerIcon = null;
    this.fields = [];
  }
  
  setType(type){this.type = type;}
  getType(){return this.type;}
  
  setText(text){this.text = text;}
  getText(){return this.text;}
  
  setColor(color){this.color = color;}
  getColor(){return this.color;}
  
  setTitle(title){this.title = title;}
  getTitle(){return this.title;}
  
  setAuthor(author){this.author = author;}
  getAuthor(){return this.author;}
  
  setAuthorUrl(url){this.authorUrl = url;}
  getAuthorUrl() {return this.authorUrl;}
  
  setAuthorIcon(url){this.authorIcon = url;}
  getAuthorUrl(){return this.authorIcon;}
  
  setDescription(description){this.description = description;}
  getDescription(){return this.description;}
  
  addField(title, text, inline){
    this.fields.push(new FieldFormat(title,text,inline));
  }
  removeField(index){this.fields.slice(index, 1);}
  removeFields(){this.fields = null;}
  
  setThumbnail(url){this.thumbnail = url;}
  getThumbnail(){return this.thumbnail;}
  
  setImage(url){this.image = url;}
  getImage(){return this.image;}
  
  setFooterText(text){this.footerText = text;}
  getFooterText(){return this.footerText;}
  
  setFooterIcon(url){this.footerIcon = icon;}
  getFooterIcon(){return this.footerIcon;}
  
  setTimestamp(bool){this.timestamp = bool;}
  getTimestamp(){return this.timestamp;}
  
  sendMessage(channel){
    if(this.type === "NORMAL"){
      channel.send(this.text);
      return;
    }
    if(this.type === "EMBED"){
      const eb = new MessageEmbed();
      for(let field of this.fields){
       eb.addField(field.getTitle(), field.getText(), field.getInline()); 
      }
      eb.setColor(this.color);
      eb.setTitle(this.title);
      eb.setAuthor(this.author, this.authorIcon, this.authorUrl);
      eb.setDescription(this.description);
      eb.setImage(this.image);
      eb.setThumbnail(this.thumbnail);
      eb.setFooter(this.footerText, this.footerIcon);
      if(this.timestamp) eb.setTimestamp();
      channel.send(eb);
      return;
    }
  }
  
  sendMessage(message){
    if(this.type === "NORMAL"){
      message.channel.send(hasUserVariable(message.author, this.text));
      return;
    }
    if(this.type === "EMBED"){
      const eb = new MessageEmbed();
      for(let field of this.fields){
        eb.addField(hasUserVariable(message.author, field.getTitle()), hasUserVariable(message.author, field.getText()), field.getInline());
      }
      eb.setColor(hasUserVariable(message.author, this.color));
      eb.setTitle(hasUserVariable(message.author, this.title));
      eb.setAuthor(hasUserVariable(message.author, this.author), hasUserVariable(message.author, this.authorIcon), hasUserVariable(message.author, this.authorUrl));
      eb.setDescription(hasUserVariable(message.author, this.description));
      eb.setThumbnail(hasUserVariable(message.author, this.thumbnail));
      eb.setImage(hasUserVariable(message.author, this.image));
      eb.setFooter(hasUserVariable(message.author, this.footerText), hasUserVariable(message.author, this.footerIcon));
      if(this.timestamp) eb.setTimestamp();
      message.channel.send(eb);
      return;
    }
  }
  
  hasUserVariable(user, v){
    if(v.includes("%user_icon%")){v = v.replace("%user_icon%",user.avatarURL);}
    if(v.includes("%user_nickname%")){v = v.replace("%user_nickname%", user.nickname);}
    if(v.includes("%user_mention%")){v = v.replace("%user_mention%", "<@" & user.id & ">")};
    return v;
  } 
}