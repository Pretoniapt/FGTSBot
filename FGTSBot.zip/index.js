const configuration = require("./configuration/bot.json");

const {Client,Intents} = require("discord.js");

const mm = require("./core/MessageManager.js");
const cm = require("./commands/CommandManager.js");

const client = new Client({partials: ['MESSAGE', 'CHANNEL', 'REACTION'],fetchAllMembers:true,intents:[Intents.FLAGS.GUILD_MESSAGES,Intents.FLAGS.DIRECT_MESSAGES,Intents.FLAGS.GUILD_MEMBERS]});

mm.loadAll();
cm.registerListener();